aiworker.com.R
==============

R code related to aiworker.com laboratory
